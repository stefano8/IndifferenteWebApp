
import java.util.Random;

public class Nodo {

    double valoreNodo[];
    double valoreArco[];
    int padre=0;
    public Nodo(double[][]valoreNo,double[][]valorear){
            this.valoreNodo= new double[valoreNo.length];
                for(int i=0,y=0;i<valoreNo.length;i++){
                    Random rand = new Random();
                    double temp= valoreNo[i][y+1] - valoreNo[i][y] ;
                    double randomNum = rand.nextFloat()* (temp) + valoreNo[i][y];
                    this.valoreNodo[i]=randomNum;
                }
            this.valoreArco= new double[valorear.length];
                for(int x=0,q=0;x<valorear.length;x++){
                    Random rand1 = new Random();
                    double temp1= valorear[x][q+1] - valorear[x][q] ;
                    double randomNum1 = rand1.nextFloat()* (temp1) + valorear[x][q];
                    this.valoreArco[x]=randomNum1;
                }
    }
    
    public int  getPadre(){
        return this.padre;
     }
    
        
     public void setPadre(int padre){
        this.padre= padre;}   
     }
