import java.util.ArrayList;



public class Percorso {

    int splitSize;

    public Percorso(int split){
        this.splitSize= split;
    }
    
    public ArrayList calcoloPercorso(int nodoPartenza,int nodoDestinazione,int altezza){
            ArrayList<Object> percorso= new ArrayList();
            percorso.add(nodoDestinazione);
            if(nodoPartenza==nodoDestinazione)return percorso;
            calcoloPercorso(percorso, nodoPartenza, nodoDestinazione,altezza);
            for(int f=0;f<percorso.size();f++){
     
                if((int)percorso.get(f)==nodoPartenza)return percorso;
            }
           
     
         
        return percorso;
         
    }
    
    public ArrayList calcoloPercorso(ArrayList percorso,int nodoPartenza,int nodo,int altezza){
        if(percorso.size()>altezza)return percorso;
            if(nodo==nodoPartenza)return percorso;
            if((nodo%this.splitSize)!=0)return calcoloPercorso(percorso, nodoPartenza, nodo+1, altezza);
            nodo=(nodo/this.splitSize)-1; 
            percorso.add(nodo);
            return calcoloPercorso(percorso, nodoPartenza, nodo, altezza);
    }
    
}
