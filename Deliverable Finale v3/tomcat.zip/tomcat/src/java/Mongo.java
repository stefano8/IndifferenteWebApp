import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.QueryBuilder;

import java.util.ArrayList;
import java.util.List;


    public class Mongo{

        private static final String dbHost = "localhost";
        private static final int dbPort = 27018;
        private static final String dbName = "prova1";
        MongoClient Client=null;
        DB db=null;

            public  void connect (){
                    this.Client= new MongoClient(dbHost, dbPort);
                    this.db= this.Client.getDB(dbName);
            }

            public void closeConnect(){
                    this.Client.close();
            }

             public  void inserisciAlbero (Albero albero){
                    DBCollection coll = db.getCollection(albero.nomealbero);
                    List<DBObject> documents = new ArrayList<>();
                    Nodo nodoradice=new Nodo(albero.valAttributoNodo,albero.valAttributoArco);
                            DBObject documentRadice = new BasicDBObject();
                            documentRadice.put("_id", 0);
                            for(int g=0;g<nodoradice.valoreNodo.length;g++){
                                documentRadice.put(albero.AttributoNodo[g], nodoradice.valoreNodo[g]);
                                }
                             for(int g=0;g<nodoradice.valoreArco.length;g++){
                                documentRadice.put(albero.AttributoArco[g], 0);
                                }
                            documents.add(documentRadice);
                    for(int u=1;u<albero.numeroNodi;u++){
                            Nodo nodo=new Nodo(albero.valAttributoNodo,albero.valAttributoArco);
                            DBObject document1 = new BasicDBObject();
                            document1.put("_id", u);
                            for(int g=0;g<nodo.valoreNodo.length;g++){
                                document1.put(albero.AttributoNodo[g], nodo.valoreNodo[g]);
                                }
                            for(int g=0;g<nodo.valoreArco.length;g++){
                                document1.put(albero.AttributoArco[g], nodo.valoreArco[g]);
                                }
                            documents.add(document1);
                            if(documents.size()>1000){
                                coll.insert(documents);
                                documents.clear();
                            }
                        }
                coll.insert(documents);
            }

          public double [] queryCalcolo(String nomeAlbero, String[] attributiSelezionati,int []obj){
                    double []val=new double[attributiSelezionati.length];
                    DBCollection collection= db.getCollection(nomeAlbero);
                    DBObject query = QueryBuilder.start().put("_id").in(obj).get();
                    DBCursor result = collection.find(query);

                    while(result.hasNext()){
                        BasicDBObject dbObject = (BasicDBObject)result.next();
                        System.out.println(dbObject);   
                        for(int z=0;z<attributiSelezionati.length;z++){
                            val[z]+= dbObject.getDouble(attributiSelezionati[z]);
                        }
                    }
                return val;
            }
          
          public void inserisciInLista(Albero albero) {
                    DBCollection collection = db.getCollection("listaAlberi");
                    DBObject document = new BasicDBObject();
                    document.put("NomeVertice", albero.nomeVertice);
                    document.put("Split", albero.splitSize);
                    document.put("_id", albero.nomealbero);
                    document.put("Altezza", albero.altezza);
                    document.put("AttributoNodo", albero.AttributoNodo);
                    document.put("AttributoArco", albero.AttributoArco);
                    document.put("NumeroNodi", albero.numeroNodi);
                    collection.insert(document);
            }

          public int recuperaNumeroNodi(String nomeAlbero1) {
                    int NumeroNodi=0;
                    String h= nomeAlbero1;
                    
                         DBCollection collection = db.getCollection("listaAlberi");
                          DBObject query =  QueryBuilder.start().put("_id").is(h).get();
                        DBCursor result = collection.find(query);
                        while(result.hasNext()){
                            BasicDBObject dbObject = (BasicDBObject)result.next();
                            NumeroNodi= dbObject.getInt("NumeroNodi");
                        }  
                          System.out.println("la numero nodi del albero è "+NumeroNodi);
                        
                return NumeroNodi;
        }
          
          
          public boolean verificaEsistenza(String nomeAlbero){
          boolean val=true;
           DBCollection collection = db.getCollection("listaAlberi");
                          DBObject query =  QueryBuilder.start().put("_id").is(nomeAlbero).get();
                            DBCursor result = collection.find(query);
                          if(result.count()>0)return val;
                          else{val=false;return val;}
                          
          }
          public int recuperaSplit(String nomeAlbero1) {
                    int split=0;
                    String h= nomeAlbero1;
                    
                         DBCollection collection = db.getCollection("listaAlberi");
                          DBObject query =  QueryBuilder.start().put("_id").is(h).get();
                        DBCursor result = collection.find(query);
                        while(result.hasNext()){
                            BasicDBObject dbObject = (BasicDBObject)result.next();
                            split= dbObject.getInt("Split");
                        }
                          System.out.println("la split del albero è"+split);
                        
                return split;
        }
            
          public int recuperaAltezza(String nomeAlbero1) {
                    int alt=0;
                    String h= nomeAlbero1;
                    
                         DBCollection collection = db.getCollection("listaAlberi");
                          DBObject query =  QueryBuilder.start().put("_id").is(h).get();
                        DBCursor result = collection.find(query);
                        while(result.hasNext()){
                            BasicDBObject dbObject = (BasicDBObject)result.next();
                            alt= dbObject.getInt("Altezza");
                        }
                          System.out.println("altezza del albero è"+alt);
                        
                return alt;
        }
            
            
            public String[] recuperaAttrNodo(String nomealbero){
                String nome= nomealbero;
                BasicDBList s = null;
                String []b;
                DBCollection collection = db.getCollection("listaAlberi");
                DBObject query =  QueryBuilder.start().put("_id").is(nome).get();
                DBCursor result = collection.find(query);
                    while(result.hasNext()){
                        BasicDBObject dbObject = (BasicDBObject)result.next();
                        s = (BasicDBList) dbObject.get("AttributoNodo");
                        }
                        b=new String[s.size()];
                        for(int u=0;u<s.size();u++){
                            b[u]=(String)s.get(u);
                        }
                return b;
                }
            
                
             public String[] recuperaAttrArco(String nomealbero){
                  String nome= nomealbero;
                BasicDBList s = null;
                String []b;
                DBCollection collection = db.getCollection("listaAlberi");
                DBObject query =  QueryBuilder.start().put("_id").is(nome).get();
                DBCursor result = collection.find(query);
                    while(result.hasNext()){
                        BasicDBObject dbObject = (BasicDBObject)result.next();
                        s = (BasicDBList) dbObject.get("AttributoArco");
                        }
                        b=new String[s.size()];
                        for(int u=0;u<s.size();u++){
                            b[u]=(String)s.get(u);
                        }
                return b;
                }
            
            public DBCursor recuperaLista(){
                        DBCollection collection = db.getCollection("listaAlberi");
                        DBCursor result = collection.find();
                return result;}
            
            
            public void cancellaAlbero(String nomeAlbero){
                        DBCollection myCollection = db.getCollection(nomeAlbero);
                        myCollection.drop();
                        BasicDBObject query = new BasicDBObject();
                        
                        query.append("_id", nomeAlbero);
                        DBCollection lista = db.getCollection("listaAlberi");
                        lista.remove(query);
            }
    }