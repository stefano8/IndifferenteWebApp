
import com.mongodb.DBCursor;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Cancella extends HttpServlet {

    
  


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String nomeAlbero= request.getParameter("NomeAlbero");
            
            Utilizzati uti= new Utilizzati();
            Boolean ris=uti.cancella(nomeAlbero);
            
            Mongo mongo= new Mongo();
            mongo.connect();
            DBCursor result= mongo.recuperaLista();
            if(result.count()==0){
                RequestDispatcher dispatcher = request.getRequestDispatcher("FormCreazione.html");
                dispatcher.include( request, response ) ;
                
                
            }else{
                //TROVARE sOLuzionE ALla CHIUSURA  mongo.closeConnect();
                request.setAttribute("Lista",result );
                RequestDispatcher dispatcher = request.getRequestDispatcher("Lista.jsp");
                dispatcher.include( request, response ) ;
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Cancella.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
}
            
           
       
    
            
            


       
           
       
    
            
            
   
