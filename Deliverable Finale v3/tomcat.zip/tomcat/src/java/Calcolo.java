import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Calcolo extends HttpServlet {

   int nodo1 ;
   int nodox ;
   
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     long inizio = System.currentTimeMillis();
        String u=request.getParameter("Nodo");
        nodo1=Integer.parseInt(u );
        String i=request.getParameter("Nodoo");
        nodox= Integer.parseInt(i);
        
        String nomeAlbero=request.getParameter("NomeAlbero");
        String[] attributiSelezionatiNodo= request.getParameterValues("listaNodo ");
        String[] attributiSelezionatiArco= request.getParameterValues("listaArco ");
            Mongo Client = new Mongo();
            Client.connect();
            int split= Client.recuperaSplit(nomeAlbero);
            int NumeroNodi= Client.recuperaNumeroNodi(nomeAlbero);
            int altezza= Client.recuperaAltezza(nomeAlbero);
            request.setAttribute("NomeAlbero",nomeAlbero);
            Percorso calcolo;
            
            calcolo = new Percorso(split);
            ArrayList po=  calcolo.calcoloPercorso(nodo1, nodox,altezza);
            boolean presente=false;
            for(int b=0;b<po.size();b++)
            {
            if(nodo1==(int)po.get(b) ){presente=true;}
            }
            if(presente){
            int []obj=new int[po.size()];
            String percorso="";
            for(int m=0;m<obj.length;m++){
            obj[m]=(int)po.get(m);
               percorso+= obj[m]+" ";
            }
            long fine = System.currentTimeMillis();
               long tempo= fine - inizio;
            if( nodox < NumeroNodi){
            
                if(nodo1!=nodox){
                 
                    request.setAttribute("tempo", tempo);
                    request.setAttribute("percorso", percorso);
                    if(attributiSelezionatiNodo!=null)
                    {
                        double [] valNodo=Client.queryCalcolo(nomeAlbero, attributiSelezionatiNodo, obj);
                        request.setAttribute("risultNodo", valNodo);
                        request.setAttribute("nomiAttNod", attributiSelezionatiNodo);
                    }
                    else
                    {
                        request.setAttribute("risultNodo", null);
                        
                    }
                    if(attributiSelezionatiArco!=null)
                    {
                        double [] valArco=Client.queryCalcolo(nomeAlbero, attributiSelezionatiArco, obj);
                        request.setAttribute("risultArco", valArco);
                         request.setAttribute("nomiAttArc", attributiSelezionatiArco);
                    }
                    else
                    {
                        request.setAttribute("risultArco", null);
                    }
                    Client.Client.close();
                    RequestDispatcher dispatcher = request.getRequestDispatcher("RISULTATO.jsp");
                    dispatcher.include( request, response ) ;
                }
                else
                {
                    
                     request.setAttribute("tempo", tempo);
                    request.setAttribute("percorso", nodo1);
                    if(attributiSelezionatiNodo!=null)
                    {
                        request.setAttribute("nomiAttNod", attributiSelezionatiNodo);
                    double [] valNodo=Client.queryCalcolo(nomeAlbero, attributiSelezionatiNodo, obj);
                    request.setAttribute("risultNodo", valNodo);
                    request.setAttribute("risultArco", null);
                    Client.Client.close();
                    RequestDispatcher dispatcher = request.getRequestDispatcher("RISULTATO.jsp");
                    dispatcher.include( request, response ) ;
                    }
                    else
                    {
                    request.setAttribute("risultNodo", null);
                    request.setAttribute("risultArco", null);
                    Client.Client.close();
                    RequestDispatcher dispatcher = request.getRequestDispatcher("RISULTATO.jsp");
                    dispatcher.include( request, response ) ;
                    }
                }
            }
            else 
            {
                String [] attrnodo=Client.recuperaAttrNodo(nomeAlbero);
                String [] attrarco =Client.recuperaAttrArco(nomeAlbero);
                request.setAttribute("NomeAlbero", nomeAlbero);
                request.setAttribute("ListaAttributiNodo",attrnodo );                
                request.setAttribute("ListaAttributiArco",attrarco );    
                RequestDispatcher dispatcher = request.getRequestDispatcher("Calcolo.jsp");
                dispatcher.include( request, response ) ;
               
              
           
            }
            
            }//end presente
            
            else
            {
                String [] attrnodo=Client.recuperaAttrNodo(nomeAlbero);
                String [] attrarco =Client.recuperaAttrArco(nomeAlbero);
                request.setAttribute("NomeAlbero", nomeAlbero);
                request.setAttribute("ListaAttributiNodo",attrnodo );                
                request.setAttribute("ListaAttributiArco",attrarco );    
                RequestDispatcher dispatcher = request.getRequestDispatcher("Calcolo.jsp");
                dispatcher.include( request, response ) ;
            }
        }//end doGet
   } //end class


           
   
   