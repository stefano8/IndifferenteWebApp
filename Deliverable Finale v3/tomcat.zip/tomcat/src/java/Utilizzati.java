
import java.util.ArrayList;
import java.util.concurrent.Semaphore;


public class Utilizzati {
    private Semaphore sem = new Semaphore(1, true);
     static ArrayList <Elemento> list=null;
    
    
    
    public Utilizzati() throws InterruptedException{
        
        sem.acquire();
    if(list==null){this.list= new ArrayList(); }
    sem.release();
    }
    
    public ArrayList <Elemento> lista(){
    return this.list;
    }
    public void aggiungi(Elemento nome) throws InterruptedException{
         sem.acquire();
        boolean pre= true;
        for(int i=0;i<list.size() && pre;i++){
            if(list.get(i).nomeAlbero.equals(nome.nomeAlbero))
            {
                list.get(i).aggiungi();
                pre= false;
            }
        }
        if(pre){list.add(nome);
        for(int i=0;i<list.size() && pre;i++){
            if(list.get(i).nomeAlbero.equals(nome.nomeAlbero))
            {
                list.get(i).aggiungi();
           
            }}
        }
        sem.release();
    }
    
    public boolean cancella(String nome) throws InterruptedException {
        sem.acquire();
        boolean ret=true;
        for(int i=0;i<list.size();i++){
            if(list.get(i).nomeAlbero.equals(nome))
                {
                if(list.get(i).contatore==1)
                {
                    list.remove(i);
                     Mongo mongo= new Mongo(); 
                    mongo.connect();
                    mongo.cancellaAlbero(nome);
                    mongo.closeConnect();
                    
                   }
                   else 
                   {
                  list.get(i).decrementa();
                   ret = false;
                   }
                }
        }
      sem.release();
        return ret;
  
    }
    
    public void decrementa(String nome){
        for(int i=0;i<list.size();i++){
            if(list.get(i).nomeAlbero.equals(nome))
                    {
                    if(list.get(i).contatore==1)
                    {
                        list.remove(i);
                    }
                    else
                    {
                        list.get(i).decrementa();
                    }
                }
    
        }
}//end decrementa

}//end class
