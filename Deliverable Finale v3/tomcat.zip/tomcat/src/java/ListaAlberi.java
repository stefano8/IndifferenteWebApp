
import com.mongodb.DBCursor;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListaAlberi extends HttpServlet {

    
Mongo mongo;	     

   
    public void service( HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
   {
       
        mongo= new Mongo();
        mongo.connect();
      DBCursor result= mongo.recuperaLista();
     if(result.count()==0){
      RequestDispatcher dispatcher = request.getRequestDispatcher("FormCreazione.html");
        dispatcher.include( request, response ) ;
    
     
     }else{
      //TROVARE sOLuzionE ALla CHIUSURA  mongo.closeConnect();
        request.setAttribute("Lista",result );
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("Lista.jsp");
        dispatcher.include( request, response ) ;
     }
    }
}
