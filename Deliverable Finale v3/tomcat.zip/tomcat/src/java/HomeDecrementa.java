
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HomeDecrementa extends HttpServlet {

  

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        
        try {
            String nome= request.getParameter("NomeAlbero");
            System.out.println(nome);
            Utilizzati uti= new Utilizzati();
            uti.decrementa(nome);
        } catch (InterruptedException ex) {
            Logger.getLogger(HomeDecrementa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("Home.html");
            try {
                dispatcher.include( request, response );
                }
            catch (IOException ex) {
            Logger.getLogger(Creazione.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }

  
}
