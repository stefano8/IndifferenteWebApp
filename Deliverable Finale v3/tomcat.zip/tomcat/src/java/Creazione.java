import com.mongodb.WriteResult;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Dispatch;


public class Creazione extends HttpServlet {

String nomeAlbero;
String nomeVertice;
int altezza ;
int splitSize;
int numAttributiNodi;
String[] nomeAttributiNodi;
double[]numeroMinAttributoNodo;
double[]numeroMaxAttributoNodo;

int numAttributiArchi;
String[] nomeAttributiArchi;
double[]numeroMinAttributoArco;
double[]numeroMaxAttributoArco;
   
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
            nomeAlbero= request.getParameter("Nome_Albero");
            nomeVertice=request.getParameter("Nome_Vertice");
            String aaltezza=request.getParameter("Depth");
            String ssplitSize=request.getParameter("Split_Size");
            splitSize= Integer.parseInt(ssplitSize);
            altezza= Integer.parseInt(aaltezza);
            String temp=request.getParameter("numeroAttrNodo");
            System.out.println(temp);
            numAttributiNodi= Integer.parseInt(temp);

            String temp1=request.getParameter("numeroAttrArco");
            numAttributiArchi= Integer.parseInt(temp1);

            numeroMinAttributoNodo= new double[numAttributiNodi];
            numeroMaxAttributoNodo= new double[numAttributiNodi];
            nomeAttributiNodi= new String[numAttributiNodi];
           
            for(int contatoreNodi1=0;contatoreNodi1 < numAttributiNodi ;contatoreNodi1++){
               
                nomeAttributiNodi[contatoreNodi1]= request.getParameter("idnomeAttributoNodo"+contatoreNodi1) ;
                numeroMinAttributoNodo[contatoreNodi1]= Integer.parseInt(request.getParameter("idvaloreminNodo"+ contatoreNodi1));
                numeroMaxAttributoNodo[contatoreNodi1]= Integer.parseInt(request.getParameter("idvaloremaxNodo"+ contatoreNodi1));
            }
           
            numeroMinAttributoArco= new double[numAttributiArchi];
            numeroMaxAttributoArco= new double[numAttributiArchi];
            nomeAttributiArchi= new String[numAttributiArchi];

            for(int contatoreArchi1=0;contatoreArchi1 < this.numAttributiArchi ;contatoreArchi1++){
               
                nomeAttributiArchi[contatoreArchi1]= request.getParameter("idnomeAttributoArco"+contatoreArchi1) ;
                numeroMinAttributoArco[contatoreArchi1]= Integer.parseInt(request.getParameter("idvaloreminArco"+ contatoreArchi1));
                numeroMaxAttributoArco[contatoreArchi1]= Integer.parseInt(request.getParameter("idvaloremaxArco"+ contatoreArchi1));
            }
                      
 Albero albero = new Albero(nomeAlbero,nomeVertice,altezza,splitSize,numeroMinAttributoNodo,numeroMaxAttributoNodo,nomeAttributiNodi
 , numeroMinAttributoArco,numeroMaxAttributoArco,nomeAttributiArchi);

           
   
        Mongo mongo=new Mongo();
        try {
            mongo.connect();
            mongo.inserisciAlbero(albero);
            mongo.inserisciInLista(albero);
          
            mongo.closeConnect();
            Elemento ele= new Elemento(nomeAlbero);
            
            Utilizzati uti= new Utilizzati();
            uti.aggiungi(ele);
            request.setAttribute("NomeAlbero", albero.nomealbero);
            request.setAttribute("ListaAttributiNodo",albero.AttributoNodo );                
            request.setAttribute("ListaAttributiArco",albero.AttributoArco );    
            RequestDispatcher dispatcher = request.getRequestDispatcher("Calcolo.jsp");
            try {
                dispatcher.include( request, response );
                }
            catch (IOException ex) {
            Logger.getLogger(Creazione.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        catch(Exception e){
            
            request.setAttribute("stampa", "nome albero già esistente");
            response.sendRedirect("FormCreazione.html");
            
            }
        
    }// end doGet
}//end Class
      
      



