
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Carica extends HttpServlet {

protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String nomeAlbero= request.getParameter("NomeAlbero");
            System.out.println(nomeAlbero);
            Mongo mongo= new Mongo();
            mongo.connect();
            String [] attrnodo=mongo.recuperaAttrNodo(nomeAlbero);
            String [] attrarco =mongo.recuperaAttrArco(nomeAlbero);
            mongo.closeConnect();
            
            request.setAttribute("NomeAlbero", nomeAlbero);
            request.setAttribute("ListaAttributiNodo",attrnodo );                
            request.setAttribute("ListaAttributiArco",attrarco );    
            RequestDispatcher dispatcher = request.getRequestDispatcher("Calcolo.jsp");
            try {
                dispatcher.include( request, response );
                }
            catch (IOException ex) {
            Logger.getLogger(Creazione.class.getName()).log(Level.SEVERE, null, ex);
            
            }


}
}
  
 