public class Albero {
    
    String nomealbero;
    String nomeVertice;
    String AttributoNodo[];
    String AttributoArco[];
    
    int numeroNodi;
    int altezza ;
    int splitSize ;

    double valAttributoNodo[][];
    double valAttributoArco[][];
    
    
        public Albero(String nomealbero,String nomeVertice,int altezza ,int splitSize,double valAttributoNodoMin[],
                double valAttributoNodoMax[],String AttributoNodo[],double valAttributoArcoMin[],
                double valAttributoArcoMax[],String AttributoArco[]){
            
                this.nomealbero= nomealbero;
                this.nomeVertice=nomeVertice;
                this.splitSize=splitSize;
                this.altezza=altezza;
                this.AttributoNodo=AttributoNodo;
                this.AttributoArco=AttributoArco;
                this.valAttributoNodo= new double [AttributoNodo.length][2];
                this.valAttributoArco= new double [AttributoArco.length][2];
                    for(int l=0;l<this.valAttributoNodo.length;l++){
                        this.valAttributoNodo[l][0]= valAttributoNodoMin[l];
                        this.valAttributoNodo[l][1]= valAttributoNodoMax[l];
                    }
                    for(int l=0;l<this.valAttributoArco.length;l++){
                        this.valAttributoArco[l][0]= valAttributoArcoMin[l];
                        this.valAttributoArco[l][1]= valAttributoArcoMax[l];
                    }
                
                this.numeroNodi=calcoloNodi();
                
        }//end costruttore
        public int calcoloNodi(){
        	if(this.altezza == 1)return 1;
                else{
                    int temp=1;
                    for(int t=2;t<= this.altezza ;t++){
                        temp= (temp * this.splitSize)+1;
                    }
                return temp;
                } 
        }
    
        public int numeroNodi(){
            return this.numeroNodi;
        }

}//end class
