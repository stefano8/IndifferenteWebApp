
public class Elemento {
    
    String nomeAlbero;
    int contatore=0;
    
    
    public Elemento(String nome){
    this.nomeAlbero= nome;
    
    }
    
    
    public void aggiungi(){
    this.contatore= this.contatore+1;
    }
    
    public void decrementa(){
    this.contatore= this.contatore-1;
    }
}
