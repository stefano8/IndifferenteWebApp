

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Seleziona extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String nome="";
            String []nomeAlbero=null;
            if(request.getParameterValues("selezionato").length>0){
                nomeAlbero= request.getParameterValues("selezionato");
                nome= nomeAlbero[0];
            }
            
            
            
            Mongo mongo= new Mongo();
            mongo.connect();
            if(mongo.verificaEsistenza(nome)){
            String[] proNodo=mongo.recuperaAttrNodo( nome);
            String[] proArco=  mongo.recuperaAttrArco( nome);
            mongo.closeConnect();
            
            Elemento ele= new Elemento(nome);
            
            Utilizzati uti= new Utilizzati();
            uti.aggiungi(ele);
            
            request.setAttribute("NomeAlbero", nome);
            request.setAttribute("ListaAttributiNodo",proNodo );                
            request.setAttribute("ListaAttributiArco",proArco );
            
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("alberoselezionato.jsp");
            dispatcher.include( request, response );
        } else{
                 RequestDispatcher dispatcher = request.getRequestDispatcher("ListaAlberi");
            dispatcher.include( request, response );
                }
        }
        catch (InterruptedException ex) {
            Logger.getLogger(Seleziona.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
